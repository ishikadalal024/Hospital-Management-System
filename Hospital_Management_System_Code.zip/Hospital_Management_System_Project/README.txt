HOSPITAL MANAGEMENT SYSTEM
Team Members:
- Ishika — 251302122
- Geetika — 251302121

Files:
- Hospital_Management_System.py: Python source code

Requirements:
- Python 3
- Uses Python standard-library modules: sqlite3, csv, and os

How to run:
1. Extract this ZIP file.
2. Open a terminal in the extracted folder.
3. Run: python Hospital_Management_System.py

The program creates/uses hospital.db in the current folder when it runs.
CSV backup and TXT report files are created in the current folder when those options are selected.
