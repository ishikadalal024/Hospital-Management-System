import sqlite3
import csv
import os

# ====================================================
#                 DATABASE CONNECTION (SQL)
# ====================================================

conn = sqlite3.connect("hospital.db")
cursor = conn.cursor()

cursor.execute("""
    CREATE TABLE IF NOT EXISTS patients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        age INTEGER,
        problem TEXT,
        category TEXT,
        hospital TEXT NOT NULL
    )
""")
conn.commit()


# ====================================================
#                 INPUT HELPER FUNCTIONS
# ====================================================

def get_text(message):
    while True:
        value = input(message).strip()
        if value != "":
            return value
        print("This field cannot be empty. Please try again.")


def get_age(message):
    while True:
        try:
            age = int(input(message))
            if 0 < age <= 120:
                return age
            print("Please enter a valid age (1-120).")
        except ValueError:
            print("Age must be a number. Please try again.")


# ====================================================
#                       CLASSES
# ====================================================

class Patient:
    def __init__(self, name, age, problem, category, patient_id=None):
        self.id = patient_id
        self.name = name
        self.age = age
        self.problem = problem
        self.category = category

    def display(self):
        print("Name:", self.name)
        print("Age:", self.age)
        print("Problem:", self.problem)
        print("Category:", self.category)


class Hospital:
    def __init__(self, name):
        self.name = name


class Receptionist:
    def __init__(self, name):
        self.name = name


class Node:
    def __init__(self, patient):
        self.patient = patient
        self.next = None


class PatientList:
    def __init__(self, hospital_name):
        self.head = None
        self.hospital_name = hospital_name

    # ---------- ADD ----------
    def add_patient(self, patient, save=True, show_message=True):

        # Save to SQL database
        if save:
            cursor.execute(
                "INSERT INTO patients (name, age, problem, category, hospital) "
                "VALUES (?, ?, ?, ?, ?)",
                (patient.name, patient.age, patient.problem,
                 patient.category, self.hospital_name)
            )
            conn.commit()
            patient.id = cursor.lastrowid

        # Add to linked list
        new_node = Node(patient)

        if self.head is None:
            self.head = new_node
        else:
            temp = self.head

            while temp.next is not None:
                temp = temp.next

            temp.next = new_node

        if show_message:
            print("\nPatient added successfully!")

    # ---------- LOAD FROM DATABASE ----------
    def load_from_database(self):
        cursor.execute(
            "SELECT id, name, age, problem, category FROM patients "
            "WHERE hospital = ? ORDER BY id",
            (self.hospital_name,)
        )
        rows = cursor.fetchall()

        for row in rows:
            patient = Patient(row[1], row[2], row[3], row[4], row[0])
            self.add_patient(patient, save=False, show_message=False)

    # ---------- DISPLAY (Emergency first) ----------
    def display_patients(self):
        if self.head is None:
            print("\nNo patients registered.")
            return

        print("\n(Emergency patients are shown first)")
        count = 1

        for category in ("Emergency", "Regular"):
            temp = self.head

            while temp is not None:
                if temp.patient.category == category:
                    print("\nPatient", count)
                    print("-------------------")
                    temp.patient.display()
                    count += 1

                temp = temp.next

    # ---------- SEARCH ----------
    def search_patient(self, name):
        temp = self.head

        while temp is not None:
            if temp.patient.name.lower() == name.lower():
                print("\nPatient Found!")
                print("-------------------")
                temp.patient.display()
                return

            temp = temp.next

        print("\nPatient not found.")

    # ---------- UPDATE ----------
    def update_patient(self, name):
        temp = self.head

        while temp is not None:

            if temp.patient.name.lower() == name.lower():

                patient = temp.patient

                print("\nCurrent Details:")
                print("-------------------")
                patient.display()

                print("\nPress Enter to keep the current value.")

                # Age
                while True:
                    new_age = input("New Age: ").strip()

                    if new_age == "":
                        break

                    try:
                        new_age = int(new_age)
                        if 0 < new_age <= 120:
                            patient.age = new_age
                            break
                        print("Please enter a valid age (1-120).")
                    except ValueError:
                        print("Age must be a number.")

                # Problem
                new_problem = input("New Problem: ").strip()
                if new_problem != "":
                    patient.problem = new_problem

                # Category
                new_category = input("New Category (1. Regular / 2. Emergency): ").strip()
                if new_category == "1":
                    patient.category = "Regular"
                elif new_category == "2":
                    patient.category = "Emergency"
                elif new_category != "":
                    print("Invalid category. Old category kept.")

                # Update in SQL database
                cursor.execute(
                    "UPDATE patients SET age = ?, problem = ?, category = ? WHERE id = ?",
                    (patient.age, patient.problem, patient.category, patient.id)
                )
                conn.commit()

                print("\nPatient updated successfully!")
                return

            temp = temp.next

        print("\nPatient not found.")

    # ---------- DELETE ----------
    def delete_patient(self, name):
        temp = self.head
        previous = None

        while temp is not None:

            if temp.patient.name.lower() == name.lower():

                if previous is None:
                    self.head = temp.next
                else:
                    previous.next = temp.next

                # Delete from SQL database
                cursor.execute("DELETE FROM patients WHERE id = ?", (temp.patient.id,))
                conn.commit()

                print("\nPatient deleted successfully!")
                return

            previous = temp
            temp = temp.next

        print("\nPatient not found.")

    # ---------- HELPERS FOR FILE HANDLING ----------
    def get_all_patients(self):
        patients = []
        temp = self.head

        while temp is not None:
            patients.append(temp.patient)
            temp = temp.next

        return patients

    def is_duplicate(self, name, age, problem):
        temp = self.head

        while temp is not None:
            p = temp.patient
            if (p.name.lower() == name.lower() and p.age == age
                    and p.problem.lower() == problem.lower()):
                return True
            temp = temp.next

        return False

    # ---------- EXPORT TO TEXT REPORT ----------
    def export_to_txt(self, filename):
        patients = self.get_all_patients()

        if len(patients) == 0:
            print("\nNo patients to export.")
            return

        with open(filename, "w") as file:
            file.write("====================================\n")
            file.write("  " + self.hospital_name.upper() + " - PATIENT REPORT\n")
            file.write("====================================\n")
            file.write("Total Patients: " + str(len(patients)) + "\n")

            count = 1
            for p in patients:
                file.write("\nPatient " + str(count) + "\n")
                file.write("-------------------\n")
                file.write("Name: " + p.name + "\n")
                file.write("Age: " + str(p.age) + "\n")
                file.write("Problem: " + p.problem + "\n")
                file.write("Category: " + p.category + "\n")
                count += 1

        print("\nReport saved to file:", filename)

    # ---------- EXPORT TO CSV ----------
    def export_to_csv(self, filename):
        patients = self.get_all_patients()

        if len(patients) == 0:
            print("\nNo patients to export.")
            return

        with open(filename, "w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["Name", "Age", "Problem", "Category"])

            for p in patients:
                writer.writerow([p.name, p.age, p.problem, p.category])

        print("\nBackup saved to file:", filename)

    # ---------- IMPORT FROM CSV ----------
    def import_from_csv(self, filename):
        if not os.path.exists(filename):
            print("\nFile not found:", filename)
            return

        added = 0
        skipped = 0

        with open(filename, "r", newline="") as file:
            reader = csv.DictReader(file)

            for row in reader:
                try:
                    name = row["Name"].strip()
                    age = int(row["Age"])
                    problem = row["Problem"].strip()
                    category = row["Category"].strip().title()

                    if name == "" or problem == "" or not (0 < age <= 120):
                        skipped += 1
                        continue

                    if category not in ("Regular", "Emergency"):
                        category = "Regular"

                    if self.is_duplicate(name, age, problem):
                        skipped += 1
                        continue

                    patient = Patient(name, age, problem, category)
                    self.add_patient(patient, save=True, show_message=False)
                    added += 1

                except (KeyError, ValueError, AttributeError):
                    skipped += 1

        print("\nImport complete!")
        print("Patients added:", added)
        print("Rows skipped (invalid/duplicate):", skipped)


# ====================================================
#                    PROGRAM START
# ====================================================

print("\n====================================================")
print("             HOSPITAL MANAGEMENT SYSTEM")
print("====================================================")

receptionist_name = input("\nEnter Receptionist Name: ")
receptionist = Receptionist(receptionist_name)

city_hospital = Hospital("City Hospital")
rosewood_hospital = Hospital("Rosewood Hospital")

city_patients = PatientList(city_hospital.name)
rosewood_patients = PatientList(rosewood_hospital.name)

# Load saved patients from the SQL database into the linked lists
city_patients.load_from_database()
rosewood_patients.load_from_database()

print("\nDatabase connected successfully!")
print("Saved patients loaded -> City Hospital:", len(city_patients.get_all_patients()),
      "| Rosewood Hospital:", len(rosewood_patients.get_all_patients()))


def select_hospital():
    print("\nSelect Hospital:")
    print("1. City Hospital")
    print("2. Rosewood Hospital")

    hospital_choice = input("Enter choice (1/2): ")

    if hospital_choice == "1":
        return city_hospital, city_patients

    elif hospital_choice == "2":
        return rosewood_hospital, rosewood_patients

    else:
        print("\nInvalid Hospital Choice!")
        return None, None


while True:

    print("\n====================================================")
    print("                    MAIN MENU")
    print("====================================================")

    print("1. Add Patient")
    print("2. Display Patients")
    print("3. Search Patient")
    print("4. Update Patient")
    print("5. Delete Patient")
    print("6. Export Patients to File")
    print("7. Import Patients from File")
    print("8. Exit")

    choice = input("\nEnter your choice: ")

    if choice == "1":

        selected_hospital, selected_list = select_hospital()

        if selected_hospital is None:
            continue

        print("\n================ PATIENT DETAILS ================")

        name = get_text("Enter Patient Name: ")
        age = get_age("Enter Patient Age: ")
        problem = get_text("Enter Patient Problem: ")

        print("\nSelect Patient Category:")
        print("1. Regular")
        print("2. Emergency")

        category_choice = input("Enter choice (1/2): ")

        if category_choice == "1":
            category = "Regular"

        elif category_choice == "2":
            category = "Emergency"

        else:
            print("\nInvalid Category!")
            print("Regular selected.")
            category = "Regular"

        patient = Patient(name, age, problem, category)

        selected_list.add_patient(patient)

        print("\n================ PATIENT REGISTERED ================")
        print("Receptionist:", receptionist.name)
        print("Hospital:", selected_hospital.name)

    elif choice == "2":

        selected_hospital, selected_list = select_hospital()

        if selected_hospital is None:
            continue

        print("\n==========", selected_hospital.name.upper(), "==========")
        selected_list.display_patients()

    elif choice == "3":

        selected_hospital, selected_list = select_hospital()

        if selected_hospital is None:
            continue

        name = input("Enter Patient Name to Search: ")
        selected_list.search_patient(name)

    elif choice == "4":

        selected_hospital, selected_list = select_hospital()

        if selected_hospital is None:
            continue

        name = input("Enter Patient Name to Update: ")
        selected_list.update_patient(name)

    elif choice == "5":

        selected_hospital, selected_list = select_hospital()

        if selected_hospital is None:
            continue

        name = input("Enter Patient Name to Delete: ")
        selected_list.delete_patient(name)

    elif choice == "6":

        selected_hospital, selected_list = select_hospital()

        if selected_hospital is None:
            continue

        print("\nSelect File Type:")
        print("1. Text Report (.txt)")
        print("2. CSV Backup (.csv)")

        file_choice = input("Enter choice (1/2): ")

        file_base = selected_hospital.name.lower().replace(" ", "_")

        if file_choice == "1":
            selected_list.export_to_txt(file_base + "_report.txt")

        elif file_choice == "2":
            selected_list.export_to_csv(file_base + "_backup.csv")

        else:
            print("\nInvalid File Type!")

    elif choice == "7":

        selected_hospital, selected_list = select_hospital()

        if selected_hospital is None:
            continue

        default_file = selected_hospital.name.lower().replace(" ", "_") + "_backup.csv"

        filename = input("Enter CSV file name (press Enter for " + default_file + "): ").strip()

        if filename == "":
            filename = default_file

        selected_list.import_from_csv(filename)

    elif choice == "8":

        conn.close()

        print("\n====================================================")
        print("     Thank you for using Hospital Management System")
        print("====================================================")

        break

    else:
        print("\nInvalid choice! Please try again.")