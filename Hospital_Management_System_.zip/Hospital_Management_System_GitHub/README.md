# Hospital Management System

A menu-driven Hospital Management System built with Python. It supports patient registration and management, hospital selection, SQLite database storage, and CSV/TXT file handling.

## Team Members

- Ishika — 251302122
- Geetika — 251302121

## Requirements

- Python 3
- Python standard-library modules: `sqlite3`, `csv`, and `os`

No external Python packages are required.

## How to Run

1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Run:

   ```bash
   python Hospital_Management_System.py
   ```

The program creates or uses `hospital.db` in the current folder. CSV backup and TXT report files are created in the current folder when those options are selected.

## Main Features

- Patient record management
- SQLite database storage
- Patient search and updates
- CSV import/export
- TXT report generation
- Input validation
